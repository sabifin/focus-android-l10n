plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.aicoinhunter"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.aicoinhunter"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }
}
