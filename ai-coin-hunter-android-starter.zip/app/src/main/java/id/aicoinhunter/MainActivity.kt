package id.aicoinhunter

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun label(text: String, size: Float, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFF172033.toInt())
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, 10, 0, 10)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFFF4F6FA.toInt())
        }

        root.addView(label("AI COIN HUNTER", 26f, true))
        root.addView(label("Android prototype • V0.1.0", 14f))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        panel.addView(label("Status: SIAP", 20f, true))
        panel.addView(label(
            "Dashboard awal berhasil dijalankan. Fitur berikutnya: pemantauan layar dengan izin pengguna dan deteksi teks reward.",
            15f
        ))
        root.addView(panel)

        root.addView(label("Fitur prototipe", 19f, true))
        root.addView(label("• Dashboard aplikasi\n• Persiapan modul OCR\n• Notifikasi peluang reward (tahap berikutnya)\n• Tidak mengakses akun atau melakukan klaim otomatis", 15f))

        root.addView(label("Catatan", 16f, true))
        root.addView(label(
            "Pemantauan layar hanya akan aktif setelah pengguna memberikan izin Android. Klaim dan interaksi TikTok harus mengikuti fitur serta aturan resmi platform.",
            13f
        ))

        setContentView(root)
    }
}
